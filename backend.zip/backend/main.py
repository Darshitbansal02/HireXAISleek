from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api import routes, openai_routes, storage_routes, auth_routes, recruiter_routes, candidate_routes, admin_routes
from core.database import Base, engine
import models  # noqa: F401 (ensure models are registered)

# create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="HireXAI Backend - Full", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes.router, prefix="/api")
app.include_router(openai_routes.router, prefix="/api/ai")
app.include_router(storage_routes.router, prefix="/api/storage")
app.include_router(auth_routes.router, prefix="/api/auth")
app.include_router(recruiter_routes.router, prefix="/api/recruiter")
app.include_router(candidate_routes.router, prefix="/api/candidate")
app.include_router(admin_routes.router, prefix="/api/admin")

@app.get("/")
async def root():
    return {"message": "Welcome to HireXAI Full Backend!"}
