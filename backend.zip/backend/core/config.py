import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./hirexai.db')
    JWT_SECRET = os.getenv('JWT_SECRET', 'supersecret')
    ACCESS_TOKEN_EXPIRE_HOURS = int(os.getenv('ACCESS_TOKEN_EXPIRE_HOURS', '12'))

settings = Settings()
