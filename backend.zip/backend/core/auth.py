from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from core.config import settings
from core.database import get_db
from models import User
from sqlalchemy.orm import Session

security = HTTPBearer()

def create_access_token(data: dict):
    from datetime import datetime, timedelta
    payload = data.copy()
    payload.update({'exp': datetime.utcnow() + timedelta(hours=settings.ACCESS_TOKEN_EXPIRE_HOURS)})
    return jwt.encode(payload, settings.JWT_SECRET, algorithm='HS256')

def decode_token(token: str):
    try:
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=['HS256'])
        return payload
    except JWTError:
        return None

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    token = credentials.credentials
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail='Invalid token')
    user = db.query(User).filter(User.email == payload.get('sub')).first()
    if not user:
        raise HTTPException(status_code=401, detail='User not found')
    return user

async def get_current_active_user(user: User = Depends(get_current_user)):
    return user
