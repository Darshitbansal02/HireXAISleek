from sqlalchemy import Column, Integer, String, Text
from core.database import Base

class Resume(Base):
    __tablename__ = 'resumes'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    filename = Column(String)
    filepath = Column(String)
    content = Column(Text)
    embedding = Column(Text)  # JSON string of vector
