from sqlalchemy import Column, Integer, String, Text
from core.database import Base

class Job(Base):
    __tablename__ = 'jobs'
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    location = Column(String)
    min_experience = Column(Integer, default=0)
    skills = Column(String)
    posted_by = Column(Integer)
