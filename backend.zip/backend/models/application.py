from sqlalchemy import Column, Integer, String
from core.database import Base

class Application(Base):
    __tablename__ = 'applications'
    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, index=True)
    candidate_id = Column(Integer, index=True)
    status = Column(String, default='applied')
