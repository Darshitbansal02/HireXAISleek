from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.database import get_db
from core.auth import get_current_active_user
from models import Resume, Job, Application

router = APIRouter()


@router.get('/jobs')
def get_all_jobs(db: Session = Depends(get_db)):
    """Return all available jobs for candidates to browse."""
    jobs = db.query(Job).all()
    result = []
    for j in jobs:
        result.append({
            'id': j.id,
            'title': j.title,
            'description': j.description,
            'location': j.location,
            'min_experience': j.min_experience,
            'skills': j.skills,
            'company': getattr(j, 'company', None),
            'type': getattr(j, 'type', None),
        })
    return {'jobs': result}


@router.get('/my-resumes')
def my_resumes(db: Session = Depends(get_db), current_user=Depends(get_current_active_user)):
    resumes = db.query(Resume).filter(Resume.user_id == current_user.id).all()
    return {'resumes': [{'id': r.id, 'filename': r.filename} for r in resumes]}

@router.post('/apply/{job_id}')
def apply_job(job_id: int, db: Session = Depends(get_db), current_user=Depends(get_current_active_user)):
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail='Job not found')
    # simple create application
    app = Application(job_id=job.id, candidate_id=current_user.id, status='applied')
    db.add(app); db.commit(); db.refresh(app)
    return {'application_id': app.id, 'status': app.status}