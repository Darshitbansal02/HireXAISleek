from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from core.database import get_db
from core.auth import get_current_active_user
from models import Job, User, Application

router = APIRouter()

class JobIn(BaseModel):
    title: str
    description: str = ''
    location: str = ''
    min_experience: int = 0
    skills: str = ''

@router.post('/post-job')
def post_job(payload: JobIn, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    if current_user.role != 'recruiter' and current_user.role != 'admin':
        raise HTTPException(status_code=403, detail='Forbidden')
    job = Job(title=payload.title, description=payload.description, location=payload.location, min_experience=payload.min_experience, skills=payload.skills, posted_by=current_user.id)
    db.add(job); db.commit(); db.refresh(job)
    return {'job': {'id': job.id, 'title': job.title}}

@router.get('/my-posts')
def my_posts(db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    jobs = db.query(Job).filter(Job.posted_by == current_user.id).all()
    return {'jobs': [{'id': j.id, 'title': j.title, 'skills': j.skills} for j in jobs]}

@router.get('/applications/{job_id}')
def applications(job_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_active_user)):
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job or job.posted_by != current_user.id:
        raise HTTPException(status_code=404, detail='Job not found or forbidden')
    apps = db.query(Application).filter(Application.job_id == job_id).all()
    return {'applications': [{'id': a.id, 'candidate_id': a.candidate_id, 'status': a.status} for a in apps]}