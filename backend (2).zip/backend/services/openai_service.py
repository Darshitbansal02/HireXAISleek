from openai import OpenAI
from core.config import settings

# Initialize OpenAI client
client = OpenAI(api_key=settings.OPENAI_API_KEY)


# --- Optimize Resume ---
async def optimize_resume(text: str):
    prompt = f"Improve this resume for ATS optimization and readability:\n\n{text}"
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert resume optimizer."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        raise Exception(f"OpenAI optimization failed: {str(e)}")


# --- Generate Resume Text ---
async def generate_resume_text(data: dict):
    prompt = f"Create a professional resume for this candidate:\n{data}"
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a professional resume writer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        raise Exception(f"OpenAI resume generation failed: {str(e)}")


# --- Generate Embedding ---
async def get_embedding(text: str):
    try:
        if not settings.OPENAI_API_KEY:
            return []
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        raise Exception(f"OpenAI embedding failed: {str(e)}")
