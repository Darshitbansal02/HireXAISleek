import httpx
import json
import asyncio
from typing import Optional, Dict, Any
import google.generativeai as genai
from core.config import settings
from core.logging import get_logger
from core.exceptions import LLMError

logger = get_logger()

class LLMService:
    def __init__(self):
        self.hf_api_key = settings.HUGGINGFACE_API_KEY
        self.deepinfra_api_key = settings.DEEPINFRA_API_KEY
        self.gemini_api_key = settings.GEMINI_API_KEY
        self.local_llm_url = settings.LOCAL_LLM_URL
        
        # Configure Gemini if key is present
        if self.gemini_api_key:
            genai.configure(api_key=self.gemini_api_key)

    async def generate_text(self, prompt: str, system_prompt: str = "You are a helpful AI assistant.") -> str:
        """
        Generates text using a multi-provider fallback strategy:
        1. Free Online LLM (HuggingFace / DeepInfra)
        2. Local LLM (Ollama/LlamaCpp)
        3. Google Gemini (Final Fallback)
        """
        
        # 1. Try Free Online LLMs
        try:
            return await self._call_huggingface(prompt, system_prompt)
        except Exception as e:
            logger.warning(f"HuggingFace failed: {e}. Trying next provider...")

        # 2. Try Local LLM
        try:
            return await self._call_local_llm(prompt, system_prompt)
        except Exception as e:
            logger.warning(f"Local LLM failed: {e}. Trying next provider...")

        # 3. Try Gemini (Final Fallback)
        try:
            return await self._call_gemini(prompt, system_prompt)
        except Exception as e:
            logger.error(f"Gemini failed: {e}. All LLM providers failed.")
            raise LLMError("All AI services are currently unavailable. Please try again later.")

    async def _call_huggingface(self, prompt: str, system_prompt: str) -> str:
        """Calls HuggingFace Inference API (Free Tier)"""
        # Using a reliable instruction-tuned model
        model_id = "mistralai/Mistral-7B-Instruct-v0.2" 
        api_url = f"https://api-inference.huggingface.co/models/{model_id}"
        headers = {"Authorization": f"Bearer {self.hf_api_key}"} if self.hf_api_key else {}
        
        full_prompt = f"<s>[INST] {system_prompt}\n\n{prompt} [/INST]"
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                api_url, 
                headers=headers, 
                json={
                    "inputs": full_prompt, 
                    "parameters": {"max_new_tokens": 1024, "temperature": 0.7, "return_full_text": False}
                },
                timeout=30.0
            )
            
            if response.status_code != 200:
                raise Exception(f"HF Status {response.status_code}: {response.text}")
                
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                return result[0].get("generated_text", "").strip()
            return str(result)

    async def _call_local_llm(self, prompt: str, system_prompt: str) -> str:
        """Calls Local LLM (e.g., Ollama)"""
        if not self.local_llm_url:
            raise Exception("Local LLM URL not configured")

        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.local_llm_url,
                json={
                    "model": "mistral", # Assume mistral or similar is pulled
                    "prompt": f"{system_prompt}\n\n{prompt}",
                    "stream": False
                },
                timeout=10.0 # Fast timeout for local check
            )
            
            if response.status_code != 200:
                raise Exception(f"Local LLM Status {response.status_code}")
                
            return response.json().get("response", "").strip()

    async def _call_gemini(self, prompt: str, system_prompt: str) -> str:
        """Calls Google Gemini API"""
        if not self.gemini_api_key:
            raise Exception("Gemini API Key not configured")
            
        model = genai.GenerativeModel('gemini-pro')
        # Gemini doesn't use system prompts the same way, so we prepend it
        full_prompt = f"{system_prompt}\n\n{prompt}"
        
        # Run synchronous Gemini call in a thread to avoid blocking event loop
        response = await asyncio.to_thread(model.generate_content, full_prompt)
        
        if not response.text:
            raise Exception("Empty response from Gemini")
            
        return response.text.strip()

llm_service = LLMService()
