from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime
from datetime import datetime
from core.database import Base

class Job(Base):
    __tablename__ = 'jobs'
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    location = Column(String)
    min_experience = Column(Integer, default=0)
    skills = Column(String)
    recruiter_id = Column(Integer) # Renamed from posted_by for consistency
    company = Column(String, default="Hiring Company")
    type = Column(String, default="Full-time")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
