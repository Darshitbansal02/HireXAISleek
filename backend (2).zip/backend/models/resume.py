from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime
from datetime import datetime
from core.database import Base

class Resume(Base):
    __tablename__ = 'resumes'
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, index=True) # Renamed from user_id
    title = Column(String, default="My Resume")
    file_url = Column(String, nullable=True)
    content = Column(Text)
    is_primary = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    embedding = Column(Text, nullable=True)  # JSON string of vector
