from typing import Optional
from pydantic import BaseModel
from datetime import datetime
from schemas.job import JobResponse
from schemas.user import UserResponse

class ApplicationBase(BaseModel):
    cover_letter: Optional[str] = None

class ApplicationCreate(ApplicationBase):
    job_id: int

class ApplicationResponse(ApplicationBase):
    id: int
    job_id: int
    candidate_id: int
    status: str
    applied_at: datetime
    job: Optional[JobResponse] = None
    candidate: Optional[UserResponse] = None

    class Config:
        from_attributes = True
