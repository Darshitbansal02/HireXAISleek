from typing import Optional
from pydantic import BaseModel
from datetime import datetime

class ResumeBase(BaseModel):
    title: str
    content: str
    file_url: Optional[str] = None

class ResumeCreate(ResumeBase):
    pass

class ResumeResponse(ResumeBase):
    id: int
    candidate_id: int
    created_at: datetime
    is_primary: bool

    class Config:
        from_attributes = True
