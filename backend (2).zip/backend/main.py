from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from core.config import settings
from core.logging import get_logger
from core.exceptions import AuthError, PermissionDeniedError, NotFoundError, ValidationError, LLMError
from api.v1 import auth, llm, candidate, recruiter
# Import other routers as they are migrated
# from api.v1 import jobs, admin

logger = get_logger()

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=f"{settings.API_V1_STR}/redoc",
)

# Auto-create tables (Removes need for manual Alembic migrations in dev)
from core.database import Base, engine
from models.user import User
from models.job import Job
from models.application import Application
from models.resume import Resume
Base.metadata.create_all(bind=engine)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[str(origin) for origin in settings.BACKEND_CORS_ORIGINS] or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Exception Handlers
@app.exception_handler(AuthError)
async def auth_exception_handler(request: Request, exc: AuthError):
    logger.warning(f"Auth error: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": "Authentication Failed", "details": exc.detail},
    )

@app.exception_handler(PermissionDeniedError)
async def permission_exception_handler(request: Request, exc: PermissionDeniedError):
    logger.warning(f"Permission denied: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": "Permission Denied", "details": exc.detail},
    )

@app.exception_handler(NotFoundError)
async def not_found_exception_handler(request: Request, exc: NotFoundError):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": "Not Found", "details": exc.detail},
    )

@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": "Validation Error", "details": exc.detail},
    )

@app.exception_handler(LLMError)
async def llm_exception_handler(request: Request, exc: LLMError):
    logger.error(f"LLM error: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": "AI Service Unavailable", "details": exc.detail},
    )

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"success": False, "error": "Internal Server Error", "details": str(exc)},
    )

# Include Routers
app.include_router(auth.router, prefix=f"{settings.API_V1_STR}/auth", tags=["Authentication"])
app.include_router(llm.router, prefix=f"{settings.API_V1_STR}/llm", tags=["AI Services"])
app.include_router(candidate.router, prefix=f"{settings.API_V1_STR}/candidate", tags=["Candidate"])
app.include_router(recruiter.router, prefix=f"{settings.API_V1_STR}/recruiter", tags=["Recruiter"])

@app.get("/")
async def root():
    return {
        "message": "Welcome to HireXAI API",
        "docs": f"{settings.API_V1_STR}/docs",
        "version": "2.0.0"
    }
