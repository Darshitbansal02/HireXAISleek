from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from services.llm_service import llm_service
from core.auth import get_current_user
from models.user import User

router = APIRouter()

class LLMRequest(BaseModel):
    prompt: str
    system_prompt: str = "You are a helpful AI assistant."

class LLMResponse(BaseModel):
    response: str
    provider: str = "auto"

@router.post("/generate", response_model=LLMResponse)
async def generate_text(
    request: LLMRequest,
    current_user: User = Depends(get_current_user)
):
    """
    Generate text using the multi-provider LLM system.
    Automatically falls back: Free -> Local -> Gemini.
    """
    try:
        response_text = await llm_service.generate_text(request.prompt, request.system_prompt)
        return {"response": response_text, "provider": "auto"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))

@router.post("/analyze-resume")
async def analyze_resume(
    resume_text: str,
    current_user: User = Depends(get_current_user)
):
    system_prompt = "You are an expert ATS (Applicant Tracking System) analyzer. Extract key skills, experience, and provide a score out of 100."
    response = await llm_service.generate_text(resume_text, system_prompt)
    return {"analysis": response}

@router.post("/job-match")
async def job_match(
    resume_text: str,
    job_description: str,
    current_user: User = Depends(get_current_user)
):
    system_prompt = "You are an expert recruiter. Compare the resume with the job description and provide a match percentage and missing skills."
    prompt = f"RESUME:\n{resume_text}\n\nJOB DESCRIPTION:\n{job_description}"
    response = await llm_service.generate_text(prompt, system_prompt)
    return {"match_analysis": response}
