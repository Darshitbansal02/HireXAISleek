from typing import List
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from core.auth import require_candidate
from models.user import User
from models.job import Job
from models.application import Application
from models.resume import Resume
from schemas.job import JobList, JobResponse
from schemas.application import ApplicationCreate, ApplicationResponse
from schemas.resume import ResumeResponse

router = APIRouter()

@router.get("/jobs", response_model=JobList)
async def get_jobs(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db),
    current_user: User = Depends(require_candidate)
):
    jobs = db.query(Job).filter(Job.is_active == True).offset(skip).limit(limit).all()
    return {"jobs": jobs}

@router.post("/apply/{job_id}", response_model=ApplicationResponse)
async def apply_for_job(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_candidate)
):
    # Check if job exists
    job = db.query(Job).filter(Job.id == job_id, Job.is_active == True).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Check if already applied
    existing_application = db.query(Application).filter(
        Application.job_id == job_id,
        Application.candidate_id == current_user.id
    ).first()
    
    if existing_application:
        raise HTTPException(status_code=400, detail="Already applied to this job")

    # Create application
    application = Application(
        job_id=job_id,
        candidate_id=current_user.id,
        status="pending",
        applied_at=datetime.utcnow()
    )
    db.add(application)
    db.commit()
    db.refresh(application)
    return application

@router.get("/my-resumes", response_model=List[ResumeResponse])
async def get_my_resumes(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_candidate)
):
    resumes = db.query(Resume).filter(Resume.candidate_id == current_user.id).all()
    return resumes
