from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from core.auth import require_recruiter
from models.user import User
from models.job import Job
from models.application import Application
from schemas.job import JobCreate, JobResponse
from schemas.application import ApplicationResponse
from datetime import datetime

router = APIRouter()

@router.post("/post-job", response_model=JobResponse)
async def post_job(
    job_in: JobCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_recruiter)
):
    job = Job(
        **job_in.dict(),
        recruiter_id=current_user.id,
        created_at=datetime.utcnow(),
        is_active=True
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return job

@router.get("/my-posts", response_model=List[JobResponse])
async def get_my_posts(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_recruiter)
):
    jobs = db.query(Job).filter(Job.recruiter_id == current_user.id).all()
    return jobs

@router.get("/applications/{job_id}", response_model=List[ApplicationResponse])
async def get_job_applications(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_recruiter)
):
    # Verify job belongs to recruiter
    job = db.query(Job).filter(Job.id == job_id, Job.recruiter_id == current_user.id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access denied")

    applications = db.query(Application).filter(Application.job_id == job_id).all()
    return applications
